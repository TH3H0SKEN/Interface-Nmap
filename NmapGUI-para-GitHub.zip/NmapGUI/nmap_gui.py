#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nmap GUI - Interface grafica para o Nmap
"""
import queue
import subprocess
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "Nmap GUI - Scanner de Rede"
DEFAULT_HOST = "192.168.1.1"
DEFAULT_PORT = "22,80,443"

SCAN_TYPES = {
    "Padrao (TCP Connect)": [],
    "SYN (-sS) [requer Admin]": ["-sS"],
    "UDP (-sU)": ["-sU"],
    "ACK (-sA)": ["-sA"],
    "Window (-sW)": ["-sW"],
    "FIN (-sF)": ["-sF"],
    "XMAS (-sX)": ["-sX"],
    "NULL (-sN)": ["-sN"],
    "Maimon (-sM)": ["-sM"],
    "Ping Sweep (-sn)": ["-sn"],
    "List Scan (-sL)": ["-sL"],
    "Idle Scan (-sI <zombie> no campo extra)": ["-sI"],
}

TIMINGS = {
    "Tempo padrao": [],
    "-T0 (Paranoid)": ["-T0"],
    "-T1 (Sneaky)": ["-T1"],
    "-T2 (Polite)": ["-T2"],
    "-T3 (Normal)": ["-T3"],
    "-T4 (Aggressive)": ["-T4"],
    "-T5 (Insane)": ["-T5"],
}

OPTIONS = [
    ("-Pn", "Ignorar descoberta de host"),
    ("-n", "Sem resolucao DNS"),
    ("-sV", "Detecao de versao"),
    ("-sC", "Scripts padrao"),
    ("--script=vuln", "Scripts de vulnerabilidades"),
    ("-O", "Detecao de SO"),
    ("-A", "Agressivo (OS+versao+script+traceroute)"),
    ("-f", "Fragmentar pacotes"),
    ("--randomize-hosts", "Randomizar hosts"),
    ("-6", "IPv6"),
    ("--traceroute", "Traceroute"),
    ("-p-", "Todas as portas (1-65535)"),
]

PORT_PRESETS = [
    "Padrao (1-1000)",
    "21,22,23,25,53,80,110,135,139,143,443,445,993,995,1723,3306,3389,5900,8080",
    "80,443,8080,8443",
    "1-65535",
    "--top-ports 100",
]


class NmapGUI:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("980x760")
        self.root.minsize(800, 600)

        self.q = queue.Queue()
        self.proc = None
        self.running = False
        self.start_time = 0
        self.exit_code = None

        self.var_host = tk.StringVar(value=DEFAULT_HOST)
        self.var_port = tk.StringVar(value=DEFAULT_PORT)
        self.var_scan = tk.StringVar(value="Padrao (TCP Connect)")
        self.var_timing = tk.StringVar(value="Tempo padrao")
        self.var_extra = tk.StringVar(value="")
        self.var_opt = {label: tk.BooleanVar(value=False) for label, _ in OPTIONS}

        self._build_ui()
        self._update_command()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        pad = {"padx": 6, "pady": 3}

        # --- Alvo -----------------------------------------------------------
        f_alvo = ttk.LabelFrame(self.root, text=" Alvo ")
        f_alvo.pack(fill=tk.X, padx=8, pady=(8, 4))
        f_alvo.columnconfigure(1, weight=1)

        ttk.Label(f_alvo, text="IP / Host:").grid(row=0, column=0, sticky=tk.W, **pad)
        ttk.Entry(f_alvo, textvariable=self.var_host, width=30).grid(
            row=0, column=1, sticky=tk.EW, **pad)

        ttk.Label(f_alvo, text="Portas:").grid(row=0, column=2, sticky=tk.W, **pad)
        self.cb_port = ttk.Combobox(
            f_alvo, textvariable=self.var_port, values=PORT_PRESETS, width=46)
        self.cb_port.grid(row=0, column=3, sticky=tk.EW, **pad)

        ttk.Label(f_alvo, text="Ex.: 80, 22-100, 1-65535 ou --top-ports 100",
                  foreground="gray").grid(row=1, column=1, columnspan=3, sticky=tk.W, **pad)

        # --- Tipo de scan ----------------------------------------------------
        f_tipo = ttk.LabelFrame(self.root, text=" Tipo de Escaneamento ")
        f_tipo.pack(fill=tk.X, padx=8, pady=4)

        ttk.Label(f_tipo, text="Tipo:").grid(row=0, column=0, sticky=tk.W, **pad)
        cb_scan = ttk.Combobox(f_tipo, textvariable=self.var_scan,
                               values=list(SCAN_TYPES.keys()), state="readonly", width=32)
        cb_scan.grid(row=0, column=1, sticky=tk.W, **pad)

        ttk.Label(f_tipo, text="Timing:").grid(row=0, column=2, sticky=tk.W, **pad)
        ttk.Combobox(f_tipo, textvariable=self.var_timing,
                     values=list(TIMINGS.keys()), state="readonly", width=18
                     ).grid(row=0, column=3, sticky=tk.W, **pad)

        ttk.Label(f_tipo, text="Opcoes extras (ex.: -D 8.8.8.8  -g 53  -e eth0  -S 1.2.3.4):"
                  ).grid(row=1, column=0, columnspan=2, sticky=tk.W, **pad)
        ttk.Entry(f_tipo, textvariable=self.var_extra).grid(
            row=1, column=2, columnspan=2, sticky=tk.EW, **pad)
        f_tipo.columnconfigure(4, weight=1)

        # --- Opcoes ----------------------------------------------------------
        f_opt = ttk.LabelFrame(self.root, text=" Opcoes ")
        f_opt.pack(fill=tk.X, padx=8, pady=4)
        for i, (label, desc) in enumerate(OPTIONS):
            r, c = divmod(i, 3)
            ttk.Checkbutton(f_opt, text=label,
                            variable=self.var_opt[label], command=self._update_command
                            ).grid(row=r, column=c, sticky=tk.W, **pad)
        for c in range(3):
            f_opt.columnconfigure(c, weight=1)

        # --- Comando + botoes -------------------------------------------------
        f_cmd = ttk.Frame(self.root)
        f_cmd.pack(fill=tk.X, padx=8, pady=4)
        ttk.Label(f_cmd, text="Comando:").grid(row=0, column=0, sticky=tk.W, **pad)
        self.lbl_cmd = tk.Label(f_cmd, text="", anchor=tk.W, font=("Consolas", 9),
                                bg="#1e1e1e", fg="#dcdcaa")
        self.lbl_cmd.grid(row=1, column=0, columnspan=5, sticky=tk.EW, **pad)

        self.btn_run = ttk.Button(f_cmd, text="Executar", command=self._run)
        self.btn_run.grid(row=2, column=0, sticky=tk.W, **pad)
        self.btn_stop = ttk.Button(f_cmd, text="Parar", command=self._stop, state=tk.DISABLED)
        self.btn_stop.grid(row=2, column=1, sticky=tk.W, **pad)
        ttk.Button(f_cmd, text="Abrir no Terminal",
                   command=self._open_terminal).grid(row=2, column=2, sticky=tk.W, **pad)
        ttk.Button(f_cmd, text="Limpar Saida", command=self._clear).grid(
            row=2, column=3, sticky=tk.W, **pad)
        ttk.Button(f_cmd, text="Salvar Saida", command=self._save).grid(
            row=2, column=4, sticky=tk.W, **pad)
        f_cmd.columnconfigure(0, weight=1)

        # --- Saida -------------------------------------------------------------
        f_out = ttk.LabelFrame(self.root, text=" Saida (execucao ao vivo) ")
        f_out.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
        self.out = tk.Text(f_out, font=("Consolas", 10), wrap=tk.NONE,
                           bg="#1e1e1e", fg="#d4d4d4", insertbackground="white")
        sb = ttk.Scrollbar(f_out, orient=tk.VERTICAL, command=self.out.yview)
        self.out.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.out.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.status = ttk.Label(self.root, text="Pronto.", anchor=tk.W,
                                relief=tk.SUNKEN)
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

        for var in [self.var_host, self.var_port, self.var_scan, self.var_timing,
                    self.var_extra]:
            if isinstance(var, tk.BooleanVar):
                continue
            w = var.get()
        self.var_host.trace_add("write", lambda *a: self._update_command())
        self.var_port.trace_add("write", lambda *a: self._update_command())
        self.var_scan.trace_add("write", lambda *a: self._update_command())
        self.var_timing.trace_add("write", lambda *a: self._update_command())
        self.var_extra.trace_add("write", lambda *a: self._update_command())

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------- comando
    def build_command(self):
        parts = ["nmap"]
        parts += SCAN_TYPES[self.var_scan.get()]
        parts += TIMINGS[self.var_timing.get()]
        for label, _ in OPTIONS:
            if self.var_opt[label].get():
                parts.append(label.split(" ")[0])
        if self.var_port.get().strip():
            parts += ["-p", self.var_port.get().strip()]
        if self.var_extra.get().strip():
            parts += self.var_extra.get().split()
        host = self.var_host.get().strip()
        if host:
            parts.append(host)
        return parts

    def _update_command(self):
        try:
            cmd = self.build_command()
        except Exception:
            cmd = ["nmap"]
        self.lbl_cmd.config(text=subprocess.list2cmdline(cmd))

    # --------------------------------------------------------------- acao
    def _run(self):
        if self.running:
            return
        host = self.var_host.get().strip()
        if not host:
            messagebox.showwarning("Alvo vazio", "Informe um IP ou host para escanear.")
            return
        self.cmd = self.build_command()
        self.out.delete("1.0", tk.END)
        self.out.insert(tk.END, "> " + subprocess.list2cmdline(self.cmd) + "\n\n")
        self.out.see(tk.END)
        self.running = True
        self.start_time = time.time()
        self.btn_run.config(state=tk.DISABLED)
        self.btn_stop.config(state=tk.NORMAL)
        self.status.config(text="Executando...")
        threading.Thread(target=self._run_nmap, daemon=True).start()
        self.root.after(50, self._poll)

    def _run_nmap(self):
        try:
            self.proc = subprocess.Popen(
                self.cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            for line in iter(self.proc.stdout.readline, ""):
                self.q.put(line)
            self.proc.stdout.close()
            self.proc.wait()
            self.exit_code = self.proc.returncode
        except FileNotFoundError:
            self.q.put("\n[ERRO] Nmap nao encontrado. Instale o Nmap e tente novamente.\n")
        except Exception as e:
            self.q.put(f"\n[ERRO] {e}\n")
        finally:
            self.q.put(None)

    def _poll(self):
        try:
            while True:
                line = self.q.get_nowait()
                if line is None:
                    self._finish()
                    return
                self.out.insert(tk.END, line)
                self.out.see(tk.END)
        except queue.Empty:
            pass
        if self.running:
            self.root.after(50, self._poll)

    def _finish(self):
        if not self.running:
            return
        self.running = False
        self.proc = None
        self.btn_run.config(state=tk.NORMAL)
        self.btn_stop.config(state=tk.DISABLED)
        elapsed = time.time() - self.start_time
        if self.exit_code == 0:
            msg = f"Concluido em {elapsed:.1f}s."
        else:
            msg = f"Concluido com erro (codigo {self.exit_code}) em {elapsed:.1f}s."
        self.out.insert(tk.END, f"\n[{msg}]\n")
        self.out.see(tk.END)
        self.status.config(text=msg)

    def _stop(self):
        if self.running and self.proc:
            self.status.config(text="Parando...")
            try:
                self.proc.terminate()
            except Exception:
                pass

    def _clear(self):
        self.out.delete("1.0", tk.END)

    def _save(self):
        if not self.out.get("1.0", tk.END).strip():
            messagebox.showinfo("Nada para salvar", "A saida esta vazia.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Arquivo de texto", "*.txt"), ("Todos", "*.*")],
            initialfile="nmap_resultado.txt",
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.out.get("1.0", tk.END))
            self.status.config(text=f"Salvo em {path}")

    def _open_terminal(self):
        host = self.var_host.get().strip()
        if not host:
            messagebox.showwarning("Alvo vazio", "Informe um IP ou host primeiro.")
            return
        cmd_str = subprocess.list2cmdline(self.build_command())
        subprocess.Popen(["cmd", "/k", cmd_str])

    def _on_close(self):
        if self.running and self.proc:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.root.destroy()


def main():
    root = tk.Tk()
    NmapGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
