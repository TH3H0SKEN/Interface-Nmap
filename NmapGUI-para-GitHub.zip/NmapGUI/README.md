# Nmap GUI

Interface gráfica em Python (Tkinter) para o [Nmap](https://nmap.org) no Windows.
Monte o escaneamento clicando em opções, veja o comando `nmap` sendo montado em
tempo real e acompanhe a saída ao vivo na janela.

> **Aviso:** escaneie apenas redes e máquinas que você tem autorização para
> escanear (sua própria rede, sua máquina, laboratório). Escaneamento sem
> permissão pode ser ilegal.

## Recursos

- Alvo por IP, intervalo, rede (`192.168.1.0/24`) ou domínio
- Presets de portas (comuns, web, todas)
- 12 tipos de escaneamento: TCP Connect, SYN, UDP, ACK, Window, FIN, XMAS, NULL, Maimon, Ping Sweep, List Scan e Idle Scan
- Timing de `-T0` a `-T5`
- Opções: `-Pn`, `-n`, `-sV`, `-sC`, `--script=vuln`, `-O`, `-A`, `-f`, `--randomize-hosts`, `-6`, `--traceroute` e `-p-`
- Campo livre para qualquer outra opção do Nmap
- Botões para executar, parar, abrir no terminal (cmd), limpar e salvar a saída em `.txt`

## Requisitos

- Windows
- [Python 3](https://www.python.org/downloads/), com "Add Python to PATH" marcado na instalação
- [Nmap](https://nmap.org/download.html) com o **Npcap**, marcando "WinPcap API-compatible Mode"

Não precisa de `pip install`: a interface usa só o Tkinter, que já vem com o Python.

## Como usar

1. Baixe o repositório (**Code → Download ZIP**) e extraia.
2. Dê dois cliques em `Iniciar_Nmap_GUI.bat`.
   Ou, pelo Prompt de Comando, rode: `py nmap_gui.py`

Os scans SYN, UDP, ACK, FIN, XMAS, NULL, detecção de SO (`-O`) e outros exigem
**administrador**: clique com o botão direito no `Iniciar_Nmap_GUI.bat` e
escolha **Executar como administrador**.

## Guia completo

O arquivo [`GUIA_Nmap_GUI.txt`](GUIA_Nmap_GUI.txt) explica cada tipo de scan,
cada opção, como ler a saída do Nmap, exemplos passo a passo e a solução dos
problemas mais comuns.

## Arquivos

| Arquivo                | Para que serve                         |
|------------------------|----------------------------------------|
| `nmap_gui.py`          | O programa (interface gráfica)         |
| `Iniciar_Nmap_GUI.bat` | Abre o programa com dois cliques       |
| `GUIA_Nmap_GUI.txt`    | Guia completo de uso                   |
