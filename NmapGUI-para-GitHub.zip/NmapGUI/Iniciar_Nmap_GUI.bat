@echo off
cd /d "%~dp0"
start "" py nmap_gui.py
